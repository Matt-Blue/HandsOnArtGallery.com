@extends('layouts.app')

@section('content')

<!-- About Services -->

    <div class="wrapper" id="about">
        <div class="inner">
            <section class="main">
                <!-- Header -->
                <header class="major">
                    <h2>Hands On Services</h2>
                </header>

                <p>
                        The service you will be getting includes an experienced artist with teaching experience. 
                        You will be greeted with a happy face and an eager to help attitude.  
                        Your experience at Hands On should be a relaxing and enjoyable with hands on assistance.
                </p>

                <p class="text-center">
                    You can find all of our upcoming events <a href="{{ route('calendar') }}">here</a>.
                </p>

            </section>
        </div>
    </div>

<!-- Workshops -->

    <div class="wrapper" id="workshops">
        <div class="inner">
            <section class="main accent2">
                <header class="major">
                    <h2>Workshops</h2><br>
                </header>

                <div class="row">
                    <div class="features 2u 12u$(medium)">
                        <section>
                            <span class="icon fa-cubes major"></span>
                        </section>
                    </div>
                    <div class="10u 12u$(medium)">
                        <p>
                            Workshops are scheduled in a three hour time slot and are posted on the website calendar for first come, first serve basis.  
                            Items will range from $20. - $40. Per person, price depends on item being painted.
                        </p>
                        <p>
                            Hands On would love to host a fundraiser for  school, church or any other organization.  
                            10% of all sales from any party will go to the organization in need.
                        </p>
                        <p>
                            Hands On is a business that is interested in keeping art within the community.  
                            If you have a request, or any suggestions please feel free to share it.  
                            This is a family owned, community driven business that wants to keep Cape Coral creative!
                        </p>
                    </div>
                </div>

            </section>
        </div>
    </div>

<!-- Parties -->

    <div class="wrapper" id="parties">
        <div class="inner">
            <section class="main accent4">
                <header class="major">
                    <h2 style="color: #555">Parties</h2><br>
                </header>

                <div class="row" style="color: #555">
                    <div class="features 2u 12u$(medium)">
                        <section>
                            <span class="icon fa-calendar major"></span>
                        </section>
                    </div>
                    <div class="10u 12u$(medium)">
                        <p>
                            A private party is booked by an individual who will gather a group of patrons to participate in a painting party.  
                            They can choose what item they want to paint, along with the design they want to put on it.   
                            All supplies are included in the price.  
                            Refreshments can be brought in, including wine and beer,(no hard liquor) and snacks for the participants.  
                            An example would be a bridal shower, painting a wine bottle on a piece of wood.  
                            Refreshments could include wine, cheese tray and crackers.
                        </p>
                        <p>
                            No prior knowledge is needed. Set up and clean up will be done for you. 
                            Paint aprons and supplies will be provided. 
                            Speakers are available.
                            All attendees must be of legal drinking age if consuming alcohol.
                        </p>
                    </div>
                </div>
            </section>
        </div>
    </div>

<!-- Open Studio -->

    <div class="wrapper" id="open_studio">
        <div class="inner">
            <section class="main accent3">
                <header class="major">
                    <h2>Open Studio</h2><br>
                </header>

                <div class="row">
                    <div class="features 2u 12u$(medium)">
                        <section>
                            <span class="icon fa-paint-brush major"></span>
                        </section>
                    </div>
                    <div class="10u 12u$(medium)">
                        <p>
                            Open Studio time is from 12 noon - 5pm for anyone to come work independently in the art studio.   
                            Individuals need to purchase an item at a discounted price that includes studio time and all the supplies needed for the project.  Open Studio time does not include instruction, but advise and opinions can be shared.  
                            The owner will be there either working on her own art, or organizing supplies for an event.  
                            Working during these hours can be a great time to develop relationships with other artists.
                        </p>
                    </div>
                </div>
                
                

            </section>
        </div>
    </div>

<!-- Pricing -->

    <div class="wrapper" id="pricing">
        <div class="inner">
            <section class="main" style="background-color: #FCFCFC">
                <header class="major">
                    <center><h2>Pricing</h2></center><br>
                </header>
                <div class-"row">
                    <div class="col-md-8 col-md-offset-2">
                        Private parties are scheduled for three hours and include a flat fee per person.  
                        A 50% deposit is required to reserve the date and various school age kids, couples, and and seniors are welcome.  
                        Refreshments can be brought in, including wine and beer, but no time. No refunds will be grated.  
                        Most items range from $20 - $40. Special requests can be made in advance. 
                        Parties can consists of hard liquor will be allowed.<center><br>
                        <b>We travel to different locations.<br>
                        Pricing is completely dependent on item to be painted.</b></center><br><br>
                    </div>
                </div><br><br>
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="table-wrapper">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Coconuts</td>
                                        <td>$29.99</td>
                                    </tr>
                                    <tr>
                                        <td>16x20 Stretched Canvases</td>
                                        <td>29.99</td>
                                    </tr>
                                    <tr>
                                        <td>8x10 Stretched Canvas</td>
                                        <td>19.99</td>
                                    </tr>
                                    <tr>
                                        <td>Hardcover Books</td>
                                        <td>19.99</td>
                                    </tr>
                                    <tr>
                                        <td>Boxes</td>
                                        <td>19.99</td>
                                    </tr>
                                    <tr>
                                        <td>Wood signs</td>
                                        <td>29.99</td>
                                    </tr>														
                                </tbody>
                            </table>
                        </div>
                        <p class="major">
                            <center><b>Subtract $10 for independent work (no guidance)</b></center>
                        </p>
                    </div>
                </div>
            </section>
        </div>
    </div>

@endsection